package chabssaltteog.balance_board.domain.post;

public enum Category {

    이슈, 라이프, 정치_경제, 기타
}
